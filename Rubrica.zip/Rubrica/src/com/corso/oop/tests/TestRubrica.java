package com.corso.oop.tests;

public class TestRubrica {
	public static void main(String[] args) {
		Menu menu = new Menu();
		menu.menu();
	}
}
