package com.corso.oop.tests;

public class TestRegistro {
	public static void main(String[] args) {
		Menu m=new Menu();
		m.menu();
	}
}
