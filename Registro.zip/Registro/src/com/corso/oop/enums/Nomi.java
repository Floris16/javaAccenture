package com.corso.oop.enums;

public enum Nomi {
	Gabriele,
	Giacomo,
	Mara,
	Massimo,
	Gianluca,
	Sara,
	Luca,
	Aldo,
	Giovanni
}
