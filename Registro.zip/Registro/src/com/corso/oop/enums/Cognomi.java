package com.corso.oop.enums;

public enum Cognomi {
	Floris,
	Trullu,
	Piras,
	Pruneddu,
	Lampis,
	Mattarella,
	Rossi,
}
