package com.corso.oop.enums;

public enum Materie {
	Italiano,
	Storia,
	Geografia,
	Scienze,
	Matematica,
	Inglese,
	Informatica,
	Ed_Fisica,
	Religione,
	Arte
}
