package com.corso.oop.es13.test;

public class TestPizzeria{
	
	public static void main(String[] args) {
		Menu menu = new Menu();
	}
}