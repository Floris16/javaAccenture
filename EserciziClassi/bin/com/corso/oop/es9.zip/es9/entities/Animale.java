package com.corso.oop.es9.entities;

public abstract class Animale {
	private String nome;
	
	public abstract String verso();
	
	public abstract String doveVivo();

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	
	
	
	
	
}
